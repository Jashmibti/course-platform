package com.learningplatform.course.controller;

import com.learningplatform.course.dto.*;
import com.learningplatform.course.entity.CourseLevel;
import com.learningplatform.course.service.CourseService;
import com.learningplatform.course.service.VideoStorageService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;

import java.util.List;

@RestController
@RequestMapping("/api/v1/courses")
@RequiredArgsConstructor
@SecurityRequirement(name = "bearerAuth")
public class CourseController {

    private final CourseService courseService;
    private final VideoStorageService videoStorageService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAnyRole('ADMIN','INSTRUCTOR')")
    public CourseResponse create(@Valid @RequestBody CourseCreateRequest request,
                                 @AuthenticationPrincipal Jwt jwt) {
        return courseService.create(request, currentUserId(jwt));
    }

    @GetMapping("/search")
    public PageResponse<CourseResponse> search(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) CourseLevel level,
            @RequestParam(required = false) String tag,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return courseService.search(keyword, category, level, tag, page, size);
    }

    @GetMapping("/{courseId}")
    public CourseResponse get(@PathVariable Long courseId) {
        return courseService.get(courseId);
    }

    @PutMapping("/{courseId}")
    @PreAuthorize("hasAnyRole('ADMIN','INSTRUCTOR')")
    public CourseResponse update(@PathVariable Long courseId,
                                 @Valid @RequestBody CourseUpdateRequest request) {
        return courseService.update(courseId, request);
    }

    @DeleteMapping("/{courseId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("hasAnyRole('ADMIN','INSTRUCTOR')")
    public void delete(@PathVariable Long courseId) {
        courseService.delete(courseId);
    }

    @PostMapping("/{courseId}/modules")
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAnyRole('ADMIN','INSTRUCTOR')")
    public ModuleResponse addModule(@PathVariable Long courseId,
                                    @Valid @RequestBody ModuleCreateRequest request) {
        return courseService.addModule(courseId, request);
    }

    @GetMapping("/{courseId}/modules")
    public List<ModuleResponse> getModules(@PathVariable Long courseId) {
        return courseService.getModules(courseId);
    }

    @PostMapping("/modules/{moduleId}/lessons")
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAnyRole('ADMIN','INSTRUCTOR')")
    public LessonResponse addLesson(@PathVariable Long moduleId,
                                    @Valid @RequestBody LessonCreateRequest request) {
        return courseService.addLesson(moduleId, request);
    }

    @GetMapping("/lessons/{lessonId}")
    public LessonResponse getLesson(@PathVariable Long lessonId) {
        return courseService.getLesson(lessonId);
    }

    @PostMapping("/lessons/{lessonId}/video")
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAnyRole('ADMIN','INSTRUCTOR')")
    public VideoUploadResponse uploadVideo(@PathVariable Long lessonId,
                                           @RequestParam("file") MultipartFile file) {
        String objectName = videoStorageService.upload(lessonId, file);
        String url = videoStorageService.presignedUrl(objectName);
        return new VideoUploadResponse(lessonId, objectName, url);
    }

    private Long currentUserId(Jwt jwt) {
        if (jwt == null) throw new IllegalStateException("Authenticated JWT is required");
        Object claim = jwt.getClaim("userId");
        if (claim == null) claim = jwt.getSubject();
        return Long.valueOf(String.valueOf(claim));
    }
}
